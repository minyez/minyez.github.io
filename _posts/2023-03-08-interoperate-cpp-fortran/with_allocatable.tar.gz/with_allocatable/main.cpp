// main.cpp
#include "interface.h"
#include <iostream>

static void generate_and_display(const int &size, int *ia)
{
    my_generate(&size, ia);
    for (int i = 0; i < size; i++)
        std::cout << ia[i] << " ";
    std::cout << std::endl;
}

int main()
{
    const int size = 9;
    int * ia = new int [size];

    generate_and_display(size, ia);
    delete [] ia;

    return 0;
}
