// interface.h
#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void my_generate(const int *size, int *ia);

#ifdef __cplusplus
}
#endif
