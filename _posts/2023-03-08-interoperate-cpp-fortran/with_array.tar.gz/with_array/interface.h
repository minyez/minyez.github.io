// interface.h
#pragma once
#ifdef __cplusplus
extern "C" {
#endif

double sum_da(const int *size, double *da);

#ifdef __cplusplus
}
#endif
