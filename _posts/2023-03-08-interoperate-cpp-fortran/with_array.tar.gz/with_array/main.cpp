// main.cpp
#include "interface.h"
#include <iostream>
#include <random>
#include <ctime>

static void display_sum_da(const int &size, double *da)
{
    for (int i = 0; i < size - 1; i++)
        std::cout << da[i] << " + ";
    if (size > 0)
        std::cout << da[size-1];
    double sum = sum_da(&size, da);
    std::cout << " = " << sum << std::endl;
}

int main()
{
    const int size = 5;
    static std::default_random_engine e(time(0));
    std::uniform_real_distribution<double> random_double(-1, 1);
    double * da = new double [size];

    for (int i = 0; i < size; i++)
        da[i] = random_double(e);

    display_sum_da(size, da);
    delete [] da;

    return 0;
}
