#include "interface.h"
#include <iostream>
int main()
{
    int i;
    i = 2;
    std::cout << i << std::endl;
    increase_by_one(&i);
    std::cout << i << std::endl;

    double d1, d2, d3;
    d1 = 1.5;
    d2 = 4.0;
    d3 = multiply_d(&d1, &d2);
    std::cout << d1 << " x " << d2 << " = " << d3 << std::endl;
    return 0;
}
