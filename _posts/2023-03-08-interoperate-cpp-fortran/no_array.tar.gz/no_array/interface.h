// interface.h
#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void increase_by_one(int *i1);
double multiply_d(double *d1, double *d2);

#ifdef __cplusplus
}
#endif
